
// The Button:
let logo = document.getElementById("logo");
let my_button = document.createElement("button");
my_button.textContent = "Click Me"
document.body.querySelector("header").appendChild(my_button);
my_button.addEventListener("click", function () {
    window.alert("Tova Soffer and Miriam Litwin, Fall 2025");
})

// The date:
window.onload = function createDate () {
    let last_modified_date = new Date(document.lastModified);
    let my_footer = document.getElementById("info");
    let now_date = new Date();
    let diff_ms = now_date-last_modified_date;
    let hour_difference = Math.floor(diff_ms / (1000 * 60 * 60));
    my_footer.textContent = `Now is ${now_date.toLocaleString()}. Last modified: ${hour_difference.toLocaleString()} hours ago on ${last_modified_date.toLocaleString()}`
    document.body.appendChild(my_footer);
}
